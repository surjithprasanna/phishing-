// PhishGuard background script

// API endpoint
const API_URL = 'http://localhost:5000/predict';

// Cache to store recently checked URLs
const urlCache = new Map();
const CACHE_EXPIRY = 30 * 60 * 1000; // 30 minutes in milliseconds

// Check if a URL is a phishing site
async function checkUrl(url) {
  // Ignore browser special pages
  if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('about:')) {
    return null;
  }
  
  // Check if URL result is cached and not expired
  const cached = urlCache.get(url);
  if (cached && (Date.now() - cached.timestamp < CACHE_EXPIRY)) {
    return cached;
  }
  
  try {
    // Contact the API
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    });
    
    if (!response.ok) {
      throw new Error(`Server responded with ${response.status}`);
    }
    
    const data = await response.json();
    
    // Cache the result
    const result = {
      url,
      isPhishing: data.result === 'phishing',
      confidence: data.confidence,
      timestamp: Date.now()
    };
    
    urlCache.set(url, result);
    
    // Also store in chrome.storage for persistence
    chrome.storage.local.set({
      [url]: {
        result: data.result,
        confidence: data.confidence,
        timestamp: Date.now()
      }
    });
    
    return result;
    
  } catch (error) {
    console.error('Error checking URL:', error);
    return null;
  }
}

// Listen for tab updates
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // Only process if the tab has completed loading
  if (changeInfo.status === 'complete' && tab.url) {
    const result = await checkUrl(tab.url);
    
    if (result) {
      // Update the extension badge
      if (result.isPhishing) {
        // Red badge with exclamation mark for phishing sites
        chrome.action.setBadgeText({ text: '!', tabId });
        chrome.action.setBadgeBackgroundColor({ color: '#ef4444', tabId });
        
        // Show a notification for high-confidence phishing detection
        if (result.confidence > 0.8) {
          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'images/icon128.png',
            title: 'PhishGuard Warning',
            message: 'This website appears to be a phishing attempt. Be careful with your personal information.',
            priority: 2
          });
        }
      } else {
        // Green badge with checkmark for safe sites
        chrome.action.setBadgeText({ text: '✓', tabId });
        chrome.action.setBadgeBackgroundColor({ color: '#10b981', tabId });
      }
    } else {
      // Clear the badge if no result
      chrome.action.setBadgeText({ text: '', tabId });
    }
  }
});

// Initialize extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('PhishGuard extension installed');
  
  // Clear any old cached data
  chrome.storage.local.clear();
  
  // Show welcome notification
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'images/icon128.png',
    title: 'PhishGuard Installed',
    message: 'PhishGuard is now protecting you from phishing websites.',
    priority: 2
  });
});

// Cleanup expired cache entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [url, data] of urlCache.entries()) {
    if (now - data.timestamp > CACHE_EXPIRY) {
      urlCache.delete(url);
    }
  }
}, 15 * 60 * 1000); // Run every 15 minutes