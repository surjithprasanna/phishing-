// API endpoint for phishing detection
const API_URL = 'http://localhost:5000/predict';

// DOM elements
const currentUrlElement = document.getElementById('current-url');
const statusContainer = document.getElementById('status-container');
const statusIndicator = document.getElementById('status-indicator');
const statusMessage = document.getElementById('status-message');
const featuresContainer = document.getElementById('features-container');
const featuresList = document.getElementById('features-list');
const checkButton = document.getElementById('check-button');
const reportButton = document.getElementById('report-button');

// Get the current tab's URL
async function getCurrentTab() {
  const queryOptions = { active: true, currentWindow: true };
  const [tab] = await chrome.tabs.query(queryOptions);
  return tab;
}

// Initialize popup
async function initializePopup() {
  const tab = await getCurrentTab();
  if (!tab || !tab.url) {
    showError('Cannot access the current page.');
    return;
  }

  // Display the current URL
  currentUrlElement.textContent = tab.url;
  
  // Check the URL
  checkUrl(tab.url);
  
  // Add event listeners
  checkButton.addEventListener('click', () => checkUrl(tab.url));
  reportButton.addEventListener('click', () => reportSite(tab.url));
}

// Check if a URL is a phishing site
async function checkUrl(url) {
  // Reset UI
  resetUI();
  
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    });
    
    if (!response.ok) {
      throw new Error(`Server responded with ${response.status}`);
    }
    
    const data = await response.json();
    displayResult(data);
    
    // Store the result in chrome storage
    chrome.storage.local.set({
      [url]: {
        result: data.result,
        confidence: data.confidence,
        timestamp: Date.now()
      }
    });
    
  } catch (error) {
    showError(`Error checking URL: ${error.message}`);
  }
}

// Display the result
function displayResult(data) {
  const { result, confidence, features } = data;
  const isPhishing = result === 'phishing';
  
  // Remove loading state
  statusIndicator.classList.remove('loading');
  
  // Update status indicator
  if (isPhishing) {
    statusIndicator.classList.add('unsafe');
    statusMessage.innerHTML = `
      <h3>Warning: Potential Phishing Site</h3>
      <p>This website appears to be a phishing attempt (${(confidence * 100).toFixed(1)}% confidence)</p>
    `;
  } else {
    statusIndicator.classList.add('safe');
    statusMessage.innerHTML = `
      <h3>Site Appears Safe</h3>
      <p>No phishing indicators detected (${(confidence * 100).toFixed(1)}% confidence)</p>
    `;
  }
  
  // Update badge
  chrome.action.setBadgeText({ 
    text: isPhishing ? '!' : '✓',
    tabId: currentTab?.id
  });
  
  chrome.action.setBadgeBackgroundColor({ 
    color: isPhishing ? '#ef4444' : '#10b981',
    tabId: currentTab?.id
  });
  
  // Display features
  if (features) {
    displayFeatures(features);
  }
}

// Display extracted features
function displayFeatures(features) {
  // Show the features container
  featuresContainer.classList.remove('hidden');
  
  // Clear previous features
  featuresList.innerHTML = '';
  
  // Select important features to show
  const importantFeatures = [
    { key: 'url_length', label: 'URL Length', format: (v) => `${v} characters` },
    { key: 'is_ip_address', label: 'Uses IP Address', format: (v) => v ? 'Yes' : 'No' },
    { key: 'has_at_symbol', label: 'Contains @ Symbol', format: (v) => v ? 'Yes' : 'No' },
    { key: 'has_ssl', label: 'SSL Certificate', format: (v) => v ? 'Present' : 'Missing' },
    { key: 'domain_age', label: 'Domain Age', format: (v) => v < 0 ? 'Unknown' : `${v} days` },
    { key: 'form_count', label: 'Form Count', format: (v) => v },
    { key: 'iframe_count', label: 'Iframe Count', format: (v) => v },
    { key: 'password_field_count', label: 'Password Fields', format: (v) => v },
    { key: 'external_form_action', label: 'External Form Action', format: (v) => v ? 'Yes' : 'No' },
  ];
  
  // Add features to the list
  importantFeatures.forEach(feature => {
    if (features[feature.key] !== undefined) {
      const listItem = document.createElement('li');
      
      // Add warning class for suspicious features
      if ((feature.key === 'is_ip_address' && features[feature.key]) ||
          (feature.key === 'has_at_symbol' && features[feature.key]) ||
          (feature.key === 'has_ssl' && !features[feature.key]) ||
          (feature.key === 'domain_age' && features[feature.key] < 30) ||
          (feature.key === 'external_form_action' && features[feature.key])) {
        listItem.classList.add('warning');
      }
      
      listItem.innerHTML = `
        <span class="feature-label">${feature.label}:</span>
        <span class="feature-value">${feature.format(features[feature.key])}</span>
      `;
      
      featuresList.appendChild(listItem);
    }
  });
}

// Report a suspicious site
function reportSite(url) {
  // In a real extension, this would send a report to your backend
  alert(`Thank you for reporting this site. Our team will review ${url} for phishing activity.`);
}

// Show error message
function showError(message) {
  statusIndicator.classList.remove('loading');
  statusIndicator.classList.add('error');
  statusMessage.innerHTML = `
    <h3>Error</h3>
    <p>${message}</p>
  `;
}

// Reset UI to loading state
function resetUI() {
  statusIndicator.className = 'status-indicator loading';
  statusMessage.innerHTML = `
    <h3>Checking site safety...</h3>
    <p>Please wait while we analyze this website</p>
  `;
  featuresContainer.classList.add('hidden');
}

// Initialize when popup is loaded
document.addEventListener('DOMContentLoaded', initializePopup);

// Store current tab globally
let currentTab;
getCurrentTab().then(tab => {
  currentTab = tab;
});