import React, { useState } from 'react';
import axios from 'axios';
import { Shield, AlertTriangle, Check, ArrowRight } from 'lucide-react';

const API_URL = 'http://localhost:5000/predict';

interface CheckResult {
  url: string;
  result: 'phishing' | 'legitimate';
  confidence: number;
  features?: Record<string, any>;
  timestamp: string;
}

const UrlChecker: React.FC = () => {
  const [url, setUrl] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [result, setResult] = useState<CheckResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [recentChecks, setRecentChecks] = useState<CheckResult[]>([]);

  const handleCheck = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      setError('Please enter a URL');
      return;
    }

    // Basic URL validation
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      setError('Please enter a valid URL starting with http:// or https://');
      return;
    }

    setIsChecking(true);
    setError(null);
    
    try {
      const response = await axios.post(API_URL, { url });
      
      const newResult: CheckResult = {
        url,
        result: response.data.result,
        confidence: response.data.confidence || 0.95,
        features: response.data.features,
        timestamp: new Date().toISOString()
      };
      
      setResult(newResult);
      setRecentChecks(prev => [newResult, ...prev].slice(0, 5));
      setUrl('');
    } catch (err) {
      console.error('Error checking URL:', err);
      setError('Error checking URL. The API might be unavailable.');
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
        <h2 className="text-2xl font-semibold text-slate-800 mb-6 flex items-center">
          <Shield className="mr-2 text-blue-600" />
          URL Scanner
        </h2>
        
        <form onSubmit={handleCheck} className="mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-grow">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter URL to check (e.g., https://example.com)"
              />
              {error && <p className="mt-2 text-red-500 text-sm">{error}</p>}
            </div>
            <button
              type="submit"
              disabled={isChecking}
              className={`px-6 py-3 rounded-lg font-medium text-white transition-all duration-200 flex items-center justify-center
                ${isChecking ? 'bg-blue-400' : 'bg-blue-600 hover:bg-blue-700'}`}
            >
              {isChecking ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Checking...
                </>
              ) : (
                <>
                  Scan URL <ArrowRight className="ml-2 h-4 w-4" />
                </>
              )}
            </button>
          </div>
        </form>

        {result && (
          <div className={`mb-8 p-6 rounded-lg border-l-4 animate-fade-in transition-all duration-300
            ${result.result === 'phishing' 
              ? 'bg-red-50 border-red-500' 
              : 'bg-green-50 border-green-500'}`}
          >
            <div className="flex items-start">
              <div className={`p-2 rounded-full 
                ${result.result === 'phishing' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}
              >
                {result.result === 'phishing' ? (
                  <AlertTriangle className="h-6 w-6" />
                ) : (
                  <Check className="h-6 w-6" />
                )}
              </div>
              <div className="ml-4 flex-grow">
                <h3 className={`text-lg font-semibold 
                  ${result.result === 'phishing' ? 'text-red-700' : 'text-green-700'}`}
                >
                  {result.result === 'phishing' ? 'Potential Phishing Site Detected' : 'Legitimate Website'}
                </h3>
                <p className="text-slate-600 mt-1 break-all">{result.url}</p>
                <div className="mt-2">
                  <div className="text-sm font-medium text-slate-700">Confidence: {(result.confidence * 100).toFixed(1)}%</div>
                  <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                    <div 
                      className={`h-2 rounded-full ${result.result === 'phishing' ? 'bg-red-500' : 'bg-green-500'}`}
                      style={{ width: `${result.confidence * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {recentChecks.length > 0 && (
          <div>
            <h3 className="text-lg font-medium text-slate-700 mb-3">Recent Scans</h3>
            <div className="space-y-2">
              {recentChecks.map((check, index) => (
                <div 
                  key={index}
                  className="flex items-center p-3 rounded-md bg-slate-50 border border-slate-200"
                >
                  <div className={`p-1 rounded-full mr-3
                    ${check.result === 'phishing' ? 'bg-red-100 text-red-500' : 'bg-green-100 text-green-500'}`}
                  >
                    {check.result === 'phishing' ? (
                      <AlertTriangle className="h-4 w-4" />
                    ) : (
                      <Check className="h-4 w-4" />
                    )}
                  </div>
                  <div className="flex-grow">
                    <div className="text-sm font-medium text-slate-800 truncate max-w-md">{check.url}</div>
                    <div className="text-xs text-slate-500">
                      {new Date(check.timestamp).toLocaleString()}
                    </div>
                  </div>
                  <div className={`text-xs font-medium px-2 py-1 rounded-full
                    ${check.result === 'phishing' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}
                  >
                    {check.result === 'phishing' ? 'Phishing' : 'Legitimate'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UrlChecker;