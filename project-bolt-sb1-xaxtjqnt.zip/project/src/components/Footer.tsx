import React from 'react';
import { Shield, Github as GitHub } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-800 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <Shield className="h-6 w-6 text-blue-400 mr-2" />
            <span className="text-lg font-semibold">PhishGuard</span>
          </div>
          
          <div className="text-slate-300 text-sm text-center md:text-right">
            <p className="mb-1">Protecting you from phishing threats with AI</p>
            <p>© {new Date().getFullYear()} PhishGuard. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;