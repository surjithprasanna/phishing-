import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, BarChart2, Info } from 'lucide-react';

const Navbar: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-600 hover:text-blue-500';
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-semibold text-slate-800">PhishGuard</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link 
              to="/" 
              className={`px-3 py-2 text-sm font-medium ${isActive('/')}`}
            >
              <div className="flex items-center">
                <Shield className="h-4 w-4 mr-1" />
                <span>Scanner</span>
              </div>
            </Link>
            <Link 
              to="/metrics" 
              className={`px-3 py-2 text-sm font-medium ${isActive('/metrics')}`}
            >
              <div className="flex items-center">
                <BarChart2 className="h-4 w-4 mr-1" />
                <span>Metrics</span>
              </div>
            </Link>
            <Link 
              to="/about" 
              className={`px-3 py-2 text-sm font-medium ${isActive('/about')}`}
            >
              <div className="flex items-center">
                <Info className="h-4 w-4 mr-1" />
                <span>About</span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;