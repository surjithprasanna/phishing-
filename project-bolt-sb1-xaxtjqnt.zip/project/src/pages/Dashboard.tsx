import React from 'react';
import UrlChecker from '../components/UrlChecker';
import { Download, Shield } from 'lucide-react';

const Dashboard: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Protect Yourself from Phishing Attacks</h1>
          <p className="text-lg text-slate-600 mb-8 max-w-3xl mx-auto">
            Our AI-powered phishing detection system helps you identify malicious websites 
            before they can steal your personal information.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <a 
              href="#scanner"
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center"
            >
              <Shield className="mr-2 h-5 w-5" />
              Scan URL Now
            </a>
            
            <a 
              href="#extension"
              className="px-6 py-3 bg-slate-200 text-slate-700 rounded-lg font-medium hover:bg-slate-300 transition-colors flex items-center"
            >
              <Download className="mr-2 h-5 w-5" />
              Get Browser Extension
            </a>
          </div>
        </div>
        
        {/* Scanner Section */}
        <div id="scanner" className="mb-16">
          <UrlChecker />
        </div>
        
        {/* Features Section */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-slate-800 mb-8 text-center">How PhishGuard Protects You</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="bg-blue-100 text-blue-600 p-3 rounded-full inline-block mb-4">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">Machine Learning Detection</h3>
              <p className="text-slate-600">
                Our advanced XGBoost model analyzes dozens of features to accurately identify phishing websites.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="bg-green-100 text-green-600 p-3 rounded-full inline-block mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"></path>
                  <path d="M3 5v14a2 2 0 0 0 2 2h16v-5"></path>
                  <path d="M18 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">Real-time Scanning</h3>
              <p className="text-slate-600">
                Get instant results about any URL you're concerned about, directly from our API.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="bg-amber-100 text-amber-600 p-3 rounded-full inline-block mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M13.5 3H12H8C6.34 3 5 4.34 5 6v14c0 1.66 1.34 3 3 3h8c1.66 0 3-1.34 3-3V10.5"></path>
                  <path d="M15 3v6h6"></path>
                  <path d="M10 16h4"></path>
                  <path d="M10 12h4"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">Comprehensive Analysis</h3>
              <p className="text-slate-600">
                We analyze URL structure, domain information, and HTML content to provide thorough protection.
              </p>
            </div>
          </div>
        </div>
        
        {/* Extension Section */}
        <div id="extension" className="bg-slate-100 rounded-lg p-8 mb-16">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-6 md:mb-0 md:pr-8">
              <h2 className="text-2xl font-bold text-slate-800 mb-4">Browser Extension</h2>
              <p className="text-slate-600 mb-6">
                Get real-time protection as you browse with our Chrome extension. It silently monitors 
                websites you visit and alerts you instantly if a potential phishing site is detected.
              </p>
              <button className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center">
                <Download className="mr-2 h-5 w-5" />
                Download Extension
              </button>
            </div>
            <div className="md:w-1/2">
              <div className="bg-white p-4 rounded-lg shadow-lg">
                <img 
                  src="https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg" 
                  alt="PhishGuard browser extension" 
                  className="rounded-md w-full"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;