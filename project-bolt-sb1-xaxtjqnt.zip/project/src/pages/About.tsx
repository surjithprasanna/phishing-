import React from 'react';
import { Shield, Lock, AlertTriangle, AlertCircle, Globe, Terminal } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-800 mb-8">About PhishGuard</h1>
        
        <div className="bg-white p-6 md:p-8 rounded-lg shadow-md mb-12">
          <h2 className="text-2xl font-semibold text-slate-800 mb-4">Our Mission</h2>
          <p className="text-slate-600 mb-6">
            PhishGuard was developed to combat the growing threat of phishing attacks 
            in our increasingly digital world. Our mission is to protect internet users 
            from malicious websites that attempt to steal personal information, financial 
            data, and credentials through deception.
          </p>
          <p className="text-slate-600">
            Using advanced machine learning techniques, specifically the XGBoost algorithm, 
            we've created a system that can accurately detect phishing websites based on 
            various features of the URL, domain, and website content.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
              <Shield className="mr-2 text-blue-600" />
              How It Works
            </h2>
            <p className="text-slate-600 mb-4">
              Our phishing detection system works through a multi-layered approach:
            </p>
            <ol className="list-decimal list-inside space-y-2 text-slate-600">
              <li>
                <span className="font-medium text-slate-700">Feature Extraction:</span> We analyze dozens of 
                features from the URL, domain information, and website content.
              </li>
              <li>
                <span className="font-medium text-slate-700">Machine Learning Model:</span> Our XGBoost model, 
                trained on thousands of examples, processes these features to make a prediction.
              </li>
              <li>
                <span className="font-medium text-slate-700">Real-time Analysis:</span> Through our API, 
                we provide instant feedback on whether a URL is likely to be a phishing attempt.
              </li>
              <li>
                <span className="font-medium text-slate-700">Browser Integration:</span> Our browser 
                extension actively monitors websites you visit and alerts you to potential threats.
              </li>
            </ol>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
              <AlertTriangle className="mr-2 text-amber-500" />
              The Threat of Phishing
            </h2>
            <p className="text-slate-600 mb-4">
              Phishing remains one of the most common and effective cyber attacks:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600">
              <li>Over 3.4 billion phishing emails are sent daily worldwide</li>
              <li>Phishing accounts for more than 80% of reported security incidents</li>
              <li>An average data breach costs organizations $4.35 million</li>
              <li>More than 60% of organizations experienced successful phishing attacks in 2023</li>
              <li>Sophisticated phishing sites can now mimic legitimate websites with 90% accuracy</li>
            </ul>
          </div>
        </div>
        
        <div className="bg-white p-6 md:p-8 rounded-lg shadow-md mb-12">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">Key Features We Analyze</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="flex">
              <div className="mr-4 mt-1">
                <Globe className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="font-medium text-slate-800 mb-1">URL Features</h3>
                <p className="text-slate-600 text-sm">
                  Length, special character usage, subdomains, presence of IP addresses, 
                  URL shorteners, and suspicious keywords.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 mt-1">
                <Lock className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="font-medium text-slate-800 mb-1">Domain Features</h3>
                <p className="text-slate-600 text-sm">
                  Domain age, WHOIS information, SSL certificate details, 
                  registration length, and hosting country.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 mt-1">
                <Terminal className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="font-medium text-slate-800 mb-1">HTML Content</h3>
                <p className="text-slate-600 text-sm">
                  Form submissions, password fields, iframe usage, 
                  external JavaScript, and redirect methods.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 mt-1">
                <AlertCircle className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="font-medium text-slate-800 mb-1">Suspicious Elements</h3>
                <p className="text-slate-600 text-sm">
                  Hidden fields, favicon inconsistencies, mismatched titles, 
                  and deceptive login forms.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 mt-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500">
                  <path d="M20 7h-9"></path>
                  <path d="M14 17H5"></path>
                  <circle cx="17" cy="17" r="3"></circle>
                  <circle cx="7" cy="7" r="3"></circle>
                </svg>
              </div>
              <div>
                <h3 className="font-medium text-slate-800 mb-1">Reputation Analysis</h3>
                <p className="text-slate-600 text-sm">
                  Domain reputation scores, blacklist status, 
                  and similarity to known brands.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 mt-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M12 16v-4"></path>
                  <path d="M12 8h.01"></path>
                </svg>
              </div>
              <div>
                <h3 className="font-medium text-slate-800 mb-1">Behavioral Patterns</h3>
                <p className="text-slate-600 text-sm">
                  Redirection chains, obfuscated scripts, session hijacking attempts, 
                  and social engineering indicators.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-8 rounded-lg text-white">
          <div className="flex flex-col md:flex-row items-center">
            <div className="mb-6 md:mb-0 md:mr-8">
              <h2 className="text-2xl font-bold mb-4">Stay Protected Online</h2>
              <p className="mb-4">
                Install our browser extension today and browse the web with confidence, 
                knowing PhishGuard is actively protecting you from phishing threats.
              </p>
              <button className="bg-white text-blue-700 px-6 py-3 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                Download Extension
              </button>
            </div>
            <div className="flex-shrink-0">
              <Shield className="h-32 w-32 md:h-40 md:w-40 opacity-80" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;