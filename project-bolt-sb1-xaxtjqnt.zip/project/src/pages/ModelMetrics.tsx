import React from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const ModelMetrics: React.FC = () => {
  // Sample metrics data - in a real app, this would come from your backend API
  const performanceMetrics = {
    accuracy: 0.97,
    precision: 0.95,
    recall: 0.96,
    f1Score: 0.955,
    auc: 0.98,
  };

  const confusionMatrix = {
    truePositives: 435,
    falsePositives: 23,
    trueNegatives: 456,
    falseNegatives: 18,
  };

  const featureImportance = {
    labels: [
      'URL Length',
      'Domain Age',
      'Special Chars',
      'SSL Present',
      'Form Tags',
      'URL Shortener',
      'IP Address',
      'External Forms',
      'Subdomain Count',
      'Iframe Usage',
    ],
    values: [0.18, 0.16, 0.14, 0.12, 0.11, 0.09, 0.08, 0.06, 0.04, 0.02],
  };

  const accuracyData = {
    labels: ['Accuracy', 'Precision', 'Recall', 'F1 Score', 'AUC'],
    datasets: [
      {
        label: 'Model Performance',
        data: [
          performanceMetrics.accuracy,
          performanceMetrics.precision,
          performanceMetrics.recall,
          performanceMetrics.f1Score,
          performanceMetrics.auc,
        ],
        backgroundColor: 'rgba(59, 130, 246, 0.6)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 1,
      },
    ],
  };

  const confusionMatrixData = {
    labels: ['True Positives', 'False Positives', 'True Negatives', 'False Negatives'],
    datasets: [
      {
        data: [
          confusionMatrix.truePositives,
          confusionMatrix.falsePositives,
          confusionMatrix.trueNegatives,
          confusionMatrix.falseNegatives,
        ],
        backgroundColor: [
          'rgba(16, 185, 129, 0.7)',  // Green for TP
          'rgba(245, 158, 11, 0.7)',  // Amber for FP
          'rgba(59, 130, 246, 0.7)',  // Blue for TN
          'rgba(239, 68, 68, 0.7)',   // Red for FN
        ],
        borderColor: [
          'rgba(16, 185, 129, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(239, 68, 68, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const featureImportanceData = {
    labels: featureImportance.labels,
    datasets: [
      {
        label: 'Feature Importance',
        data: featureImportance.values,
        backgroundColor: 'rgba(59, 130, 246, 0.6)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-800 mb-8">Model Performance Metrics</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Performance Metrics */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-slate-800 mb-4">Performance Metrics</h2>
            
            <div className="h-80">
              <Bar 
                data={accuracyData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  scales: {
                    y: {
                      beginAtZero: true,
                      max: 1,
                      ticks: {
                        callback: function(value) {
                          return value.toLocaleString(undefined, { style: 'percent', minimumFractionDigits: 0 });
                        }
                      }
                    }
                  },
                  plugins: {
                    tooltip: {
                      callbacks: {
                        label: function(context) {
                          return (context.raw * 100).toFixed(1) + '%';
                        }
                      }
                    }
                  }
                }}
              />
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mt-6">
              {Object.entries(performanceMetrics).map(([key, value]) => (
                <div key={key} className="text-center">
                  <div className="text-lg font-semibold text-blue-600">
                    {(value * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-slate-600 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Confusion Matrix */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-slate-800 mb-4">Confusion Matrix</h2>
            
            <div className="h-80 flex items-center justify-center">
              <div className="w-3/4">
                <Doughnut 
                  data={confusionMatrixData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right',
                      },
                    },
                  }}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="bg-green-50 p-3 rounded-md">
                <div className="text-lg font-semibold text-green-600">
                  {confusionMatrix.truePositives}
                </div>
                <div className="text-sm text-slate-700">
                  True Positives
                </div>
                <div className="text-xs text-slate-500">
                  Correctly identified phishing sites
                </div>
              </div>
              
              <div className="bg-amber-50 p-3 rounded-md">
                <div className="text-lg font-semibold text-amber-600">
                  {confusionMatrix.falsePositives}
                </div>
                <div className="text-sm text-slate-700">
                  False Positives
                </div>
                <div className="text-xs text-slate-500">
                  Legitimate sites marked as phishing
                </div>
              </div>
              
              <div className="bg-blue-50 p-3 rounded-md">
                <div className="text-lg font-semibold text-blue-600">
                  {confusionMatrix.trueNegatives}
                </div>
                <div className="text-sm text-slate-700">
                  True Negatives
                </div>
                <div className="text-xs text-slate-500">
                  Correctly identified legitimate sites
                </div>
              </div>
              
              <div className="bg-red-50 p-3 rounded-md">
                <div className="text-lg font-semibold text-red-600">
                  {confusionMatrix.falseNegatives}
                </div>
                <div className="text-sm text-slate-700">
                  False Negatives
                </div>
                <div className="text-xs text-slate-500">
                  Phishing sites missed by the model
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Feature Importance */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-12">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Feature Importance</h2>
          
          <div className="h-80">
            <Bar 
              data={featureImportanceData}
              options={{
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  x: {
                    beginAtZero: true,
                    max: Math.max(...featureImportance.values) * 1.1,
                  }
                },
                plugins: {
                  legend: {
                    display: false,
                  }
                }
              }}
            />
          </div>
        </div>
        
        {/* Model Details */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Model Details</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-slate-700 mb-2">Model Architecture</h3>
              <ul className="list-disc list-inside space-y-1 text-slate-600">
                <li>Algorithm: XGBoost Classifier</li>
                <li>Trees: 100</li>
                <li>Max Depth: 6</li>
                <li>Learning Rate: 0.1</li>
                <li>Subsample: 0.8</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-slate-700 mb-2">Training Information</h3>
              <ul className="list-disc list-inside space-y-1 text-slate-600">
                <li>Dataset Size: 10,000 URLs</li>
                <li>Training/Test Split: 80/20</li>
                <li>Last Updated: June 15, 2025</li>
                <li>Feature Count: 25</li>
                <li>Cross-Validation: 5-fold</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModelMetrics;