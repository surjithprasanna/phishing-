from flask import Flask, request, jsonify
import joblib
import os
import sys
from flask_cors import CORS
import pandas as pd
import json

# Add model directory to path to import feature_extraction
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'model'))
from feature_extraction import extract_features

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Paths to model files
MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', 'model', 'phishing_model.pkl')
SCALER_PATH = os.path.join(os.path.dirname(__file__), '..', 'model', 'scaler.pkl')

# Check if model exists, if not create a sample one
if not os.path.exists(MODEL_PATH) or not os.path.exists(SCALER_PATH):
    print("Model files not found. Training a sample model...")
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'model'))
    from train import train_model
    train_model()

# Load the model
try:
    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    print("Model loaded successfully")
except Exception as e:
    print(f"Error loading model: {e}")
    model = None
    scaler = None

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    if model is not None and scaler is not None:
        return jsonify({"status": "ok", "message": "Service is healthy"})
    else:
        return jsonify({"status": "error", "message": "Model not loaded"}), 500

@app.route('/predict', methods=['POST', 'OPTIONS'])
def predict():
    """
    Endpoint to predict if a URL is a phishing site
    
    Expects JSON input with URL:
    {
        "url": "https://example.com"
    }
    
    Returns prediction result:
    {
        "url": "https://example.com",
        "result": "phishing" or "legitimate",
        "confidence": 0.95,
        "features": {...}
    }
    """
    # Handle preflight OPTIONS request
    if request.method == 'OPTIONS':
        return '', 200
    
    if model is None or scaler is None:
        return jsonify({
            "error": "Model is not loaded. Please check server logs."
        }), 500
    
    # Get URL from request
    data = request.get_json()
    
    if not data or 'url' not in data:
        return jsonify({
            "error": "Missing required parameter: url"
        }), 400
    
    url = data['url']
    
    try:
        # Extract features
        features = extract_features(url)
        
        # Convert to DataFrame
        features_df = pd.DataFrame([features])
        
        # Fill missing values with zeros
        for col in model.feature_names_in_:
            if col not in features_df.columns:
                features_df[col] = 0
        
        # Ensure columns are in the right order
        features_df = features_df[model.feature_names_in_]
        
        # Scale features
        features_scaled = scaler.transform(features_df)
        
        # Make prediction
        prediction = model.predict(features_scaled)[0]
        probability = model.predict_proba(features_scaled)[0, 1]
        
        # Determine result
        result = "phishing" if prediction == 1 else "legitimate"
        
        # Keep track of predictions for analytics
        log_prediction(url, result, probability)
        
        return jsonify({
            "url": url,
            "result": result,
            "confidence": float(probability),
            "features": features
        })
        
    except Exception as e:
        return jsonify({
            "error": f"Error processing URL: {str(e)}"
        }), 500

def log_prediction(url, result, confidence):
    """Log predictions to a file for analytics"""
    log_dir = os.path.join(os.path.dirname(__file__), 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    log_path = os.path.join(log_dir, 'predictions.jsonl')
    
    log_entry = {
        "timestamp": pd.Timestamp.now().isoformat(),
        "url": url,
        "result": result,
        "confidence": float(confidence)
    }
    
    with open(log_path, 'a') as f:
        f.write(json.dumps(log_entry) + '\n')

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs(os.path.join(os.path.dirname(__file__), 'logs'), exist_ok=True)
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)