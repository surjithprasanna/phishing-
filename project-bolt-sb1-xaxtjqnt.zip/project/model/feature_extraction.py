import re
import ssl
import urllib.parse
from datetime import datetime
import socket
import requests
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup
import whois
import tldextract

def extract_features(url):
    """
    Extract features from a URL for phishing detection
    
    Args:
        url (str): The URL to analyze
        
    Returns:
        dict: Dictionary of extracted features
    """
    features = {}
    
    # Sanitize URL
    if not url.startswith('http'):
        url = 'http://' + url
    
    # URL Features
    features.update(extract_url_features(url))
    
    # Domain Features
    try:
        features.update(extract_domain_features(url))
    except Exception as e:
        print(f"Error extracting domain features: {e}")
        # Fill with defaults if domain features can't be extracted
        features.update({
            'domain_age': -1,
            'domain_expiry': -1,
            'has_ssl': 0,
            'is_ip_address': 1 if is_ip_address(urllib.parse.urlparse(url).netloc) else 0
        })
    
    # HTML/Content Features
    try:
        features.update(extract_html_features(url))
    except Exception as e:
        print(f"Error extracting HTML features: {e}")
        # Fill with defaults if content features can't be extracted
        features.update({
            'form_count': 0,
            'external_form_action': 0,
            'iframe_count': 0,
            'password_field_count': 0,
            'external_script_count': 0
        })
    
    return features

def extract_url_features(url):
    """Extract features from the URL itself"""
    features = {}
    
    # Parse the URL
    parsed_url = urllib.parse.urlparse(url)
    domain = parsed_url.netloc
    path = parsed_url.path
    
    # URL length
    features['url_length'] = len(url)
    
    # Number of dots in domain
    features['dot_count'] = domain.count('.')
    
    # Number of hyphens in domain
    features['hyphen_count'] = domain.count('-')
    
    # Presence of @ symbol
    features['has_at_symbol'] = 1 if '@' in url else 0
    
    # Presence of double slashes in path
    features['has_double_slash'] = 1 if '//' in path else 0
    
    # Presence of IP address in domain
    features['is_ip_address'] = 1 if is_ip_address(domain) else 0
    
    # Presence of URL shortening service
    short_services = ['bit.ly', 'tinyurl.com', 't.co', 'goo.gl']
    features['is_shortened'] = 1 if any(service in domain for service in short_services) else 0
    
    # Presence of suspicious TLDs
    suspicious_tlds = ['.xyz', '.top', '.club', '.online']
    extracted = tldextract.extract(url)
    features['suspicious_tld'] = 1 if f'.{extracted.suffix}' in suspicious_tlds else 0
    
    # Number of subdomains
    if extracted.subdomain:
        features['subdomain_count'] = len(extracted.subdomain.split('.'))
    else:
        features['subdomain_count'] = 0
        
    # URL path depth
    features['path_depth'] = len([p for p in path.split('/') if p])
    
    # Count of digits in domain
    features['domain_digit_count'] = sum(c.isdigit() for c in domain)
    
    # Count of query parameters
    features['query_param_count'] = len(urllib.parse.parse_qs(parsed_url.query))
    
    return features

def extract_domain_features(url):
    """Extract features related to the domain"""
    features = {}
    
    parsed_url = urllib.parse.urlparse(url)
    domain = parsed_url.netloc
    
    # Remove port number if present
    if ':' in domain:
        domain = domain.split(':')[0]
    
    # Get domain age and expiry
    try:
        domain_info = whois.whois(domain)
        
        # Domain creation date
        if domain_info.creation_date:
            if isinstance(domain_info.creation_date, list):
                creation_date = domain_info.creation_date[0]
            else:
                creation_date = domain_info.creation_date
                
            domain_age = (datetime.now() - creation_date).days
            features['domain_age'] = domain_age
        else:
            features['domain_age'] = -1
        
        # Domain expiry
        if domain_info.expiration_date:
            if isinstance(domain_info.expiration_date, list):
                expiry_date = domain_info.expiration_date[0]
            else:
                expiry_date = domain_info.expiration_date
                
            days_to_expiry = (expiry_date - datetime.now()).days
            features['domain_expiry'] = days_to_expiry
        else:
            features['domain_expiry'] = -1
    except Exception as e:
        features['domain_age'] = -1
        features['domain_expiry'] = -1
    
    # Check for SSL certificate
    try:
        hostname = domain
        context = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=3) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                features['has_ssl'] = 1
    except:
        features['has_ssl'] = 0
        
    return features

def extract_html_features(url):
    """Extract features from the HTML content of the URL"""
    features = {}
    
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        req = Request(url, headers=headers)
        response = urlopen(req, timeout=5)
        html_content = response.read().decode('utf-8')
        
        # Parse the HTML
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Count the number of forms
        forms = soup.find_all('form')
        features['form_count'] = len(forms)
        
        # Check for external form actions
        if forms:
            parsed_url = urllib.parse.urlparse(url)
            base_domain = parsed_url.netloc
            
            for form in forms:
                if form.get('action'):
                    action = form['action']
                    if action.startswith('http'):
                        form_domain = urllib.parse.urlparse(action).netloc
                        if form_domain != base_domain:
                            features['external_form_action'] = 1
                            break
            else:
                features['external_form_action'] = 0
        else:
            features['external_form_action'] = 0
        
        # Count iframes
        features['iframe_count'] = len(soup.find_all('iframe'))
        
        # Count password fields
        features['password_field_count'] = len(soup.find_all('input', {'type': 'password'}))
        
        # Count external scripts
        scripts = soup.find_all('script', {'src': True})
        external_scripts = 0
        parsed_url = urllib.parse.urlparse(url)
        base_domain = parsed_url.netloc
        
        for script in scripts:
            src = script['src']
            if src.startswith('http'):
                script_domain = urllib.parse.urlparse(src).netloc
                if script_domain != base_domain:
                    external_scripts += 1
        
        features['external_script_count'] = external_scripts
        
    except Exception as e:
        features['form_count'] = 0
        features['external_form_action'] = 0
        features['iframe_count'] = 0
        features['password_field_count'] = 0
        features['external_script_count'] = 0
    
    return features

def is_ip_address(domain):
    """Check if the domain is an IP address"""
    pattern = r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$"
    match = re.match(pattern, domain)
    
    if match:
        for i in range(1, 5):
            if int(match.group(i)) > 255:
                return False
        return True
    
    return False