import joblib
import pandas as pd
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, 
    confusion_matrix, roc_curve, roc_auc_score, classification_report
)
import matplotlib.pyplot as plt
import seaborn as sns
from feature_extraction import extract_features
import os

def evaluate_model(model_path='../model/phishing_model.pkl', scaler_path='../model/scaler.pkl'):
    """
    Evaluate the trained model on the test set
    """
    # Create data directory if it doesn't exist
    os.makedirs('../data', exist_ok=True)
    
    try:
        # Load test data
        test_data = pd.read_csv('../data/phishing_dataset.csv')
        # Use the last 20% of data for testing
        test_size = int(len(test_data) * 0.2)
        test_data = test_data.tail(test_size)
        
        # Extract features and target
        X_test = test_data.drop('is_phishing', axis=1)
        y_test = test_data['is_phishing']
        
        # Load model and scaler
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        
        # Scale features
        X_test_scaled = scaler.transform(X_test)
        
        # Make predictions
        y_pred = model.predict(X_test_scaled)
        y_prob = model.predict_proba(X_test_scaled)[:, 1]
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        cm = confusion_matrix(y_test, y_pred)
        auc = roc_auc_score(y_test, y_prob)
        
        # Print metrics
        print("\nModel Performance Metrics:")
        print(f"Accuracy: {accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall: {recall:.4f}")
        print(f"F1 Score: {f1:.4f}")
        print(f"AUC: {auc:.4f}")
        
        print("\nConfusion Matrix:")
        print(cm)
        
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred))
        
        # Save metrics to file
        metrics = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'auc': auc,
            'confusion_matrix': {
                'true_positives': cm[1, 1],
                'false_positives': cm[0, 1],
                'true_negatives': cm[0, 0],
                'false_negatives': cm[1, 0]
            }
        }
        
        pd.DataFrame([metrics]).to_json('../data/model_metrics.json', orient='records')
        
        # Plot ROC curve
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        plt.figure(figsize=(10, 8))
        plt.plot(fpr, tpr, color='blue', lw=2, label=f'ROC curve (AUC = {auc:.4f})')
        plt.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver Operating Characteristic')
        plt.legend(loc="lower right")
        plt.savefig('../data/roc_curve.png')
        
        # Plot confusion matrix
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                    xticklabels=['Legitimate', 'Phishing'],
                    yticklabels=['Legitimate', 'Phishing'])
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        plt.title('Confusion Matrix')
        plt.savefig('../data/confusion_matrix.png')
        
        return metrics
        
    except Exception as e:
        print(f"Error during evaluation: {e}")
        return None

def test_url(url, model_path='../model/phishing_model.pkl', scaler_path='../model/scaler.pkl'):
    """
    Test a single URL with the trained model
    """
    try:
        # Extract features
        features = extract_features(url)
        
        # Convert to DataFrame
        features_df = pd.DataFrame([features])
        
        # Load model and scaler
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        
        # Fill missing values with zeros
        for col in model.feature_names_in_:
            if col not in features_df.columns:
                features_df[col] = 0
        
        # Ensure columns are in the right order
        features_df = features_df[model.feature_names_in_]
        
        # Scale features
        features_scaled = scaler.transform(features_df)
        
        # Make prediction
        prediction = model.predict(features_scaled)[0]
        probability = model.predict_proba(features_scaled)[0, 1]
        
        result = {
            'url': url,
            'is_phishing': bool(prediction),
            'probability': float(probability),
            'features': features
        }
        
        return result
        
    except Exception as e:
        print(f"Error testing URL: {e}")
        return {
            'url': url,
            'error': str(e)
        }

if __name__ == "__main__":
    # Test evaluation
    print("Evaluating model...")
    evaluate_model()
    
    # Test URLs
    test_urls = [
        'https://www.google.com',
        'http://malicious-looking-site.xyz/login.php',
        'https://bit.ly/3xR5tY8',
        'http://192.168.1.1/admin'
    ]
    
    print("\nTesting individual URLs:")
    for url in test_urls:
        result = test_url(url)
        if 'error' in result:
            print(f"{url}: Error - {result['error']}")
        else:
            status = "PHISHING" if result['is_phishing'] else "LEGITIMATE"
            print(f"{url}: {status} (confidence: {result['probability']:.2f})")