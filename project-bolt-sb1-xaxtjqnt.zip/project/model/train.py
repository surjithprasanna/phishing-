import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import xgboost as xgb
import matplotlib.pyplot as plt
import os

# Create data directory if it doesn't exist
os.makedirs('../data', exist_ok=True)

def generate_sample_data(n_samples=10000):
    """
    Generate synthetic data for demonstration purposes
    In a real-world scenario, you would use actual labeled phishing data
    """
    np.random.seed(42)
    
    # Generate random features
    data = {
        'url_length': np.random.normal(loc=50, scale=30, size=n_samples),
        'dot_count': np.random.randint(1, 10, size=n_samples),
        'hyphen_count': np.random.randint(0, 5, size=n_samples),
        'has_at_symbol': np.random.randint(0, 2, size=n_samples),
        'has_double_slash': np.random.randint(0, 2, size=n_samples),
        'is_ip_address': np.random.randint(0, 2, size=n_samples),
        'is_shortened': np.random.randint(0, 2, size=n_samples),
        'suspicious_tld': np.random.randint(0, 2, size=n_samples),
        'subdomain_count': np.random.randint(0, 5, size=n_samples),
        'path_depth': np.random.randint(0, 8, size=n_samples),
        'domain_digit_count': np.random.randint(0, 10, size=n_samples),
        'query_param_count': np.random.randint(0, 10, size=n_samples),
        'domain_age': np.random.normal(loc=500, scale=300, size=n_samples),
        'domain_expiry': np.random.normal(loc=1000, scale=500, size=n_samples),
        'has_ssl': np.random.randint(0, 2, size=n_samples),
        'form_count': np.random.randint(0, 6, size=n_samples),
        'external_form_action': np.random.randint(0, 2, size=n_samples),
        'iframe_count': np.random.randint(0, 5, size=n_samples),
        'password_field_count': np.random.randint(0, 4, size=n_samples),
        'external_script_count': np.random.randint(0, 10, size=n_samples),
    }
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Generate labels (phishing vs legitimate) with more sophisticated logic
    # Increase likelihood of phishing for certain feature combinations
    phishing_score = (
        0.7 * df['is_ip_address'] + 
        0.6 * df['has_at_symbol'] + 
        0.5 * df['external_form_action'] +
        0.4 * df['suspicious_tld'] +
        0.3 * (df['domain_age'] < 100).astype(int) +
        0.3 * (df['has_ssl'] == 0).astype(int) +
        0.2 * (df['password_field_count'] > 0).astype(int) * (df['external_form_action'] > 0).astype(int) +
        0.2 * df['is_shortened'] +
        0.1 * (df['dot_count'] > 3).astype(int) +
        0.1 * (df['iframe_count'] > 0).astype(int)
    )
    
    # Normalize and add random noise
    phishing_score = phishing_score / 3.0 + np.random.normal(0, 0.1, n_samples)
    
    # Convert to binary labels with balanced classes
    threshold = np.percentile(phishing_score, 50)  # 50% phishing, 50% legitimate
    df['is_phishing'] = (phishing_score >= threshold).astype(int)
    
    return df

def train_model():
    print("Preparing dataset...")
    # Load or generate dataset
    try:
        df = pd.read_csv('../data/phishing_dataset.csv')
        print("Loaded existing dataset")
    except FileNotFoundError:
        print("Generating synthetic dataset for demonstration")
        df = generate_sample_data()
        df.to_csv('../data/phishing_dataset.csv', index=False)
    
    print(f"Dataset shape: {df.shape}")
    print(f"Phishing examples: {df['is_phishing'].sum()}")
    print(f"Legitimate examples: {len(df) - df['is_phishing'].sum()}")
    
    # Prepare features and target
    X = df.drop('is_phishing', axis=1)
    y = df['is_phishing']
    
    # Create X_train, X_test, y_train, y_test splits
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Save scaler for inference
    joblib.dump(scaler, '../model/scaler.pkl')
    
    # Train XGBoost model
    print("Training XGBoost model...")
    model = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        objective='binary:logistic',
        random_state=42
    )
    
    model.fit(X_train_scaled, y_train)
    
    # Save the model
    joblib.dump(model, '../model/phishing_model.pkl')
    print("Model saved to ../model/phishing_model.pkl")
    
    # Make predictions
    y_pred = model.predict(X_test_scaled)
    
    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)
    
    print("\nModel Performance Metrics:")
    print(f"Accuracy: {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    print(f"F1 Score: {f1:.4f}")
    
    print("\nConfusion Matrix:")
    print(cm)
    
    # Get feature importance
    feature_importance = model.feature_importances_
    feature_names = X.columns
    
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': feature_importance
    }).sort_values(by='Importance', ascending=False)
    
    print("\nTop 10 Most Important Features:")
    print(importance_df.head(10))
    
    # Save feature importances
    importance_df.to_csv('../data/feature_importance.csv', index=False)
    
    # Plot feature importances
    plt.figure(figsize=(12, 8))
    plt.barh(importance_df['Feature'][:10], importance_df['Importance'][:10])
    plt.xlabel('Importance')
    plt.title('Top 10 Feature Importances')
    plt.tight_layout()
    plt.savefig('../data/feature_importance.png')
    
    return model, scaler

if __name__ == "__main__":
    # Create model directory if it doesn't exist
    os.makedirs('../model', exist_ok=True)
    train_model()
    print("Training complete!")